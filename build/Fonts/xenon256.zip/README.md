# Xenon256
An open-source pixel grotesk typeface family of two fonts, Regular & Corrupted.
https://behance.net/cybrneon/xenon256

![Xenon256_behance_pres-01](https://user-images.githubusercontent.com/48329074/146239601-d32c69b5-a69e-433d-8ad1-5299bb126326.png)

## Add Xenon 256 to your device
Please download the latest zip files from the releases page for installation.

## Web Usage
Coming soon...

## Building the fonts from source
There are no requirements so you can directly download the Glyphs file and work on it. Of course only on a macOS machine (I couldn't use FontLab Studio because my school stopped buying licenses for it and instead focused on Glyphs only, witch is a pain in the +ss because I had to borrow a MacBook Pro from the school's secretary; switching from my pc to mac to work on this family).

## Donations
If you wish to donate to the work, you can do so by sending me money:
BTC: bc1qxmpkq6k90z5xc5hf0gj4xn53w52yz85xq3jm47
ETH: 0x6a62479c5a7968E638D80539B280F3E9346D726D
DOGE: DD7eDB8JqmckczTqtUunNBx7iVXZhQqyxk
SHIB: 0x6a62479c5a7968E638D80539B280F3E9346D726D
