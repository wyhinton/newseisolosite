Free for personal and commercial use

J'adore travailler la typo, c'est un élément auquel je suis très sensible de manière générale, et je prends beaucoup de plaisir à en concevoir...

Cette nouvelle typo se prénomme "BEBEL" un petit clin d'oeil à mon papa ❤️

En effet Bebel était son surnom plus jeune, tiré de notre nom de famille "Belliot". Mon père ne vient pas du tout du domaine artistique/com. etc... Mais il a toujours été de bon conseil pendant mes créations.

Lorsque j'habitais encore avec lui, j'avais pour habitude de lui montrer mes projets pour avoir son regard dessus, et ainsi pouvoir rebondir sur mes idées.

https://www.behance.net/camillebel5ff5